package com.example.demo.email;

import java.util.HashMap;
import java.util.Map;

import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/email")
public class EmailController {

    private final EmailService emailService;

    public EmailController(EmailService emailService) {
        this.emailService = emailService;
    }

    // ?몄쬆踰덊샇 ?대찓???꾩넚
    @PostMapping("/send")
    public Map<String, String> sendCode(
            @RequestBody Map<String, String> request) {

        String email = request.get("email");

        emailService.sendVerificationCode(email);

        Map<String, String> response = new HashMap<>();
        response.put("message", "?몄쬆踰덊샇瑜??꾩넚?덉뒿?덈떎.");

        return response;
    }

    // ?몄쬆踰덊샇 ?뺤씤
    @PostMapping("/verify")
    public Map<String, String> verifyCode(
            @RequestBody Map<String, String> request) {

        String email = request.get("email");
        String code = request.get("code");

        boolean success =
                emailService.verifyCode(email, code);

        Map<String, String> response = new HashMap<>();

        if (success) {
            response.put("message", "?대찓???몄쬆???깃났?덉뒿?덈떎.");
        } else {
            response.put("message", "?몄쬆踰덊샇媛 ??멸굅??留뚮즺?섏뿀?듬땲??");
        }

        return response;
    }
}
