package com.example.demo.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.demo.entity.Payment;

public interface PaymentRepository
        extends JpaRepository<Payment, Long> {

    // 二쇰Ц踰덊샇濡?寃곗젣 李얘린
    Optional<Payment> findByOrderId(String orderId);

    // Toss paymentKey濡?寃곗젣 李얘린
    Optional<Payment> findByPaymentKey(String paymentKey);

    // ?ъ슜??+ 寃곗젣醫낅쪟 + 寃곗젣?곹깭濡?寃곗젣 李얘린
    Optional<Payment> findFirstByUserIdAndPaymentTypeAndStatus(
            Long userId,
            String paymentType,
            String status
    );
}
