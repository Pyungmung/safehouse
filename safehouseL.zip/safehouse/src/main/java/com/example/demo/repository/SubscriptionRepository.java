package com.example.demo.repository;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.demo.entity.Subscription;

public interface SubscriptionRepository
        extends JpaRepository<Subscription, Long> {

    // ?ъ슜??踰덊샇濡?援щ룆 議고쉶
    Optional<Subscription> findByUserId(Long userId);

    // ACTIVE ?곹깭??援щ룆 ?꾩껜 議고쉶
    List<Subscription> findByStatus(String status);

    // ACTIVE ?곹깭?대㈃??寃곗젣?쇱씠 ??援щ룆 議고쉶
    List<Subscription> findByStatusAndNextPaymentAtLessThanEqual(
            String status,
            LocalDateTime now
    );
}
