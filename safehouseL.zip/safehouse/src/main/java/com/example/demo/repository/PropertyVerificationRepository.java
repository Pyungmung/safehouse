package com.example.demo.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.demo.entity.PropertyVerification;

public interface PropertyVerificationRepository
        extends JpaRepository<PropertyVerification, Long> {

    Optional<PropertyVerification> findByPropertyId(Long propertyId);
}
