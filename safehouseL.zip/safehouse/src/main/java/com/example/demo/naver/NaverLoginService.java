package com.example.demo.naver;

import java.util.Map;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestClient;

@Service
public class NaverLoginService {

    private final String clientId;
    private final String clientSecret;
    private final String redirectUri;

    private final RestClient restClient;

    public NaverLoginService(
            @Value("${naver.client-id}") String clientId,
            @Value("${naver.client-secret}") String clientSecret,
            @Value("${naver.redirect-uri}") String redirectUri) {

        this.clientId = clientId;
        this.clientSecret = clientSecret;
        this.redirectUri = redirectUri;

        this.restClient = RestClient.create();
    }

    // ?ㅼ씠踰?濡쒓렇???섏씠吏 二쇱냼 ?앹꽦
    public String getLoginUrl(String state) {

        return "https://nid.naver.com/oauth2.0/authorize"
                + "?response_type=code"
                + "&client_id=" + clientId
                + "&redirect_uri=" + redirectUri
                + "&state=" + state;
    }

    // ?ㅼ씠踰꾩뿉??Access Token 諛쏄린
    @SuppressWarnings("unchecked")
    public String getAccessToken(
            String code,
            String state) {

        Map<String, Object> response =
                restClient.get()
                        .uri(uriBuilder -> uriBuilder
                                .scheme("https")
                                .host("nid.naver.com")
                                .path("/oauth2.0/token")
                                .queryParam(
                                        "grant_type",
                                        "authorization_code"
                                )
                                .queryParam(
                                        "client_id",
                                        clientId
                                )
                                .queryParam(
                                        "client_secret",
                                        clientSecret
                                )
                                .queryParam(
                                        "code",
                                        code
                                )
                                .queryParam(
                                        "state",
                                        state
                                )
                                .build())
                        .retrieve()
                        .body(Map.class);

        if (response == null ||
                response.get("access_token") == null) {

            throw new RuntimeException(
                    "?ㅼ씠踰?濡쒓렇???좏겙 諛쒓툒???ㅽ뙣?덉뒿?덈떎."
            );
        }

        return response.get("access_token").toString();
    }

    // Access Token?쇰줈 ?ㅼ씠踰??뚯썝 ?뺣낫 媛?몄삤湲?    @SuppressWarnings("unchecked")
    public Map<String, Object> getUserInfo(
            String accessToken) {

        Map<String, Object> response =
                restClient.get()
                        .uri(
                                "https://openapi.naver.com/v1/nid/me"
                        )
                        .header(
                                "Authorization",
                                "Bearer " + accessToken
                        )
                        .retrieve()
                        .body(Map.class);

        if (response == null ||
                response.get("response") == null) {

            throw new RuntimeException(
                    "?ㅼ씠踰??ъ슜???뺣낫瑜?媛?몄삤吏 紐삵뻽?듬땲??"
            );
        }

        return (Map<String, Object>)
                response.get("response");
    }
}
