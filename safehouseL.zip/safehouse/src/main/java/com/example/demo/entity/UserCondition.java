package com.example.demo.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "user_condition")
public class UserCondition {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    // ?뚯썝 踰덊샇
    private Long userId;

    // ?붽툒
    private Long salary;

    // 吏곸옣 ?꾩튂
    private String workplace;

    // 蹂댁쬆湲?
    private Long deposit;

    // ?뚮┝ ?ㅼ젙
    // true = ?뚮┝ 諛쏄린
    // false = ?뚮┝ 諛쏆? ?딄린
    private Boolean notificationEnabled;


    // 湲곕낯 ?앹꽦??
    public UserCondition() {

    }


    // Getter / Setter

    public Long getId() {
        return id;
    }

    public Long getUserId() {
        return userId;
    }

    public void setUserId(Long userId) {
        this.userId = userId;
    }

    public Long getSalary() {
        return salary;
    }

    public void setSalary(Long salary) {
        this.salary = salary;
    }

    public String getWorkplace() {
        return workplace;
    }

    public void setWorkplace(String workplace) {
        this.workplace = workplace;
    }

    public Long getDeposit() {
        return deposit;
    }

    public void setDeposit(Long deposit) {
        this.deposit = deposit;
    }

    public Boolean getNotificationEnabled() {
        return notificationEnabled;
    }

    public void setNotificationEnabled(Boolean notificationEnabled) {
        this.notificationEnabled = notificationEnabled;
    }
}
