package com.example.demo.dto;

import jakarta.validation.constraints.NotBlank;

public class LoginRequestDto {

    @NotBlank(message = "?꾩씠?붾? ?낅젰?댁＜?몄슂.")
    private String username;

    @NotBlank(message = "鍮꾨?踰덊샇瑜??낅젰?댁＜?몄슂.")
    private String password;

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }
}
