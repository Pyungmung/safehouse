package com.example.demo.controller;

import java.nio.charset.StandardCharsets;
import java.util.Base64;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.example.demo.entity.Payment;
import com.example.demo.repository.PaymentRepository;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

@RestController
@RequestMapping("/api/webhook")
public class WebhookController {

    private final PaymentRepository paymentRepository;

    @Value("${tosspayments.secret-key}")
    private String secretKey;

    public WebhookController(PaymentRepository paymentRepository) {
        this.paymentRepository = paymentRepository;
    }

    @PostMapping("/toss/payment")
    public ResponseEntity<String> tossPaymentWebhook(
            @RequestBody String body) {

        try {
            ObjectMapper objectMapper = new ObjectMapper();
            JsonNode webhookJson = objectMapper.readTree(body);

            String orderId = webhookJson.path("orderId").asText();
            String webhookStatus = webhookJson.path("status").asText();

            System.out.println("Toss Webhook ?섏떊");
            System.out.println("orderId : " + orderId);
            System.out.println("webhook status : " + webhookStatus);

            if (orderId == null || orderId.isBlank()) {
                return ResponseEntity.badRequest()
                        .body("orderId媛 ?놁뒿?덈떎.");
            }

            Optional<Payment> paymentResult =
                    paymentRepository.findByOrderId(orderId);

            if (paymentResult.isEmpty()) {
                return ResponseEntity.ok("Webhook received");
            }

            Payment payment = paymentResult.get();
            String paymentKey = payment.getPaymentKey();

            if (paymentKey == null || paymentKey.isBlank()) {
                return ResponseEntity.ok("paymentKey ?놁쓬");
            }

            String authorization =
                    Base64.getEncoder().encodeToString(
                            (secretKey + ":")
                                    .getBytes(StandardCharsets.UTF_8)
                    );

            HttpHeaders headers = new HttpHeaders();
            headers.set(
                    "Authorization",
                    "Basic " + authorization
            );

            HttpEntity<Void> request =
                    new HttpEntity<>(headers);

            ResponseEntity<String> response =
                    new RestTemplate().exchange(
                            "https://api.tosspayments.com/v1/payments/"
                                    + paymentKey,
                            HttpMethod.GET,
                            request,
                            String.class
                    );

            if (response.getStatusCode().is2xxSuccessful()) {

                JsonNode tossPayment =
                        objectMapper.readTree(response.getBody());

                String realStatus =
                        tossPayment.path("status").asText();

                if ("DONE".equals(realStatus)) {
                    payment.setStatus("PAID");

                } else if ("CANCELED".equals(realStatus)
                        || "PARTIAL_CANCELED".equals(realStatus)) {

                    payment.setStatus("CANCELED");

                } else if ("ABORTED".equals(realStatus)) {
                    payment.setStatus("FAILED");

                } else if ("EXPIRED".equals(realStatus)) {
                    payment.setStatus("EXPIRED");

                } else {
                    payment.setStatus(realStatus);
                }

                paymentRepository.save(payment);
            }

            return ResponseEntity.ok("Webhook processed");

        } catch (Exception e) {
            System.out.println(
                    "Webhook 泥섎━ ?ㅻ쪟 : "
                    + e.getMessage()
            );

            return ResponseEntity
                    .internalServerError()
                    .body("Webhook 泥섎━ ?ㅽ뙣");
        }
    }
}
