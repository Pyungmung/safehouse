package com.example.demo.dto;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;

public class SignUpRequestDto {

    @NotBlank(message = "?꾩씠?붾? ?낅젰?댁＜?몄슂.")
    @Size(min = 4, max = 20, message = "?꾩씠?붾뒗 4~20?먮줈 ?낅젰?댁＜?몄슂.")
    private String username;

    @NotBlank(message = "鍮꾨?踰덊샇瑜??낅젰?댁＜?몄슂.")
    @Size(min = 6, max = 30, message = "鍮꾨?踰덊샇??6~30?먮줈 ?낅젰?댁＜?몄슂.")
    private String password;

    @NotBlank(message = "?대찓?쇱쓣 ?낅젰?댁＜?몄슂.")
    @Email(message = "?щ컮瑜??대찓???뺤떇???꾨떃?덈떎.")
    private String email;

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }
}
