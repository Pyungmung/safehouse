package com.example.demo.scheduler;

import java.time.LocalDateTime;
import java.util.List;

import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import com.example.demo.controller.PaymentController;
import com.example.demo.entity.Subscription;
import com.example.demo.repository.SubscriptionRepository;

@Component
public class SubscriptionScheduler {

    private final SubscriptionRepository subscriptionRepository;
    private final PaymentController paymentController;

    public SubscriptionScheduler(
            SubscriptionRepository subscriptionRepository,
            PaymentController paymentController) {

        this.subscriptionRepository = subscriptionRepository;
        this.paymentController = paymentController;
    }

    @Scheduled(
            cron = "0 0 9 * * *",
            zone = "Asia/Seoul"
    )
    public void autoSubscriptionPayment() {

        LocalDateTime now = LocalDateTime.now();

        List<Subscription> subscriptions =
                subscriptionRepository
                        .findByStatusAndNextPaymentAtLessThanEqual(
                                "ACTIVE",
                                now
                        );

        System.out.println(
                "자동결제 대상: "
                + subscriptions.size()
                + "명"
        );

        for (Subscription subscription : subscriptions) {

            try {

                Object result =
                        paymentController.paySubscription(
                                subscription.getUserId()
                        );

                System.out.println(
                        "userId "
                        + subscription.getUserId()
                        + " 자동결제 결과 : "
                        + result
                );

            } catch (Exception e) {

                System.out.println(
                        "userId "
                        + subscription.getUserId()
                        + " 자동결제 실패 : "
                        + e.getMessage()
                );
            }
        }
    }
}