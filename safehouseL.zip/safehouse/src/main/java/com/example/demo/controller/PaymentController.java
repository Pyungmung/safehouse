package com.example.demo.controller;

import java.nio.charset.StandardCharsets;
import java.time.LocalDateTime;
import java.util.Base64;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestTemplate;

import com.example.demo.entity.Payment;
import com.example.demo.entity.Subscription;
import com.example.demo.repository.PaymentRepository;
import com.example.demo.repository.SubscriptionRepository;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

@RestController
@RequestMapping("/api/payment")
public class PaymentController {

    private final PaymentRepository paymentRepository;
    private final SubscriptionRepository subscriptionRepository;

    @Value("${tosspayments.secret-key}")
    private String secretKey;

    @Value("${tosspayments.billing-secret-key}")
    private String billingSecretKey;

    public PaymentController(
            PaymentRepository paymentRepository,
            SubscriptionRepository subscriptionRepository) {
        this.paymentRepository = paymentRepository;
        this.subscriptionRepository = subscriptionRepository;
    }

    @PostMapping("/report/confirm")
    public Object confirmReportPayment(
            @RequestParam Long userId,
            @RequestParam String paymentKey,
            @RequestParam String orderId,
            @RequestParam Long amount) {

        try {
            if (amount == null || amount <= 0) {
                return "寃곗젣 湲덉븸???щ컮瑜댁? ?딆뒿?덈떎.";
            }

            HttpHeaders headers = makeHeaders(secretKey);

            Map<String, Object> body = new HashMap<>();
            body.put("paymentKey", paymentKey);
            body.put("orderId", orderId);
            body.put("amount", amount);

            ResponseEntity<String> response = new RestTemplate().exchange(
                    "https://api.tosspayments.com/v1/payments/confirm",
                    HttpMethod.POST,
                    new HttpEntity<>(body, headers),
                    String.class
            );

            if (!response.getStatusCode().is2xxSuccessful()) {
                return "寃곗젣 ?뱀씤???ㅽ뙣?덉뒿?덈떎.";
            }

            Payment payment = new Payment();
            payment.setUserId(userId);
            payment.setPaymentKey(paymentKey);
            payment.setOrderId(orderId);
            payment.setAmount(amount);
            payment.setPaymentType("REPORT");
            payment.setStatus("PAID");

            return paymentRepository.save(payment);

        } catch (HttpClientErrorException e) {
            return "Toss 寃곗젣 ?ㅻ쪟 : " + e.getResponseBodyAsString();
        } catch (Exception e) {
            return "寃곗젣 泥섎━ 以??ㅻ쪟媛 諛쒖깮?덉뒿?덈떎.";
        }
    }

    @PostMapping("/billing/issue")
    public Object issueBillingKey(
            @RequestParam Long userId,
            @RequestParam String authKey,
            @RequestParam String customerKey,
            @RequestParam Long amount) {

        try {
            if (amount == null || amount <= 0) {
                return "援щ룆 湲덉븸???щ컮瑜댁? ?딆뒿?덈떎.";
            }

            HttpHeaders headers = makeHeaders(billingSecretKey);

            Map<String, Object> body = new HashMap<>();
            body.put("authKey", authKey);
            body.put("customerKey", customerKey);

            ResponseEntity<String> response = new RestTemplate().exchange(
                    "https://api.tosspayments.com/v1/billing/authorizations/issue",
                    HttpMethod.POST,
                    new HttpEntity<>(body, headers),
                    String.class
            );

            if (!response.getStatusCode().is2xxSuccessful()) {
                return "BillingKey 諛쒓툒???ㅽ뙣?덉뒿?덈떎.";
            }

            JsonNode json = new ObjectMapper().readTree(response.getBody());
            String billingKey = json.path("billingKey").asText();

            Optional<Subscription> result =
                    subscriptionRepository.findByUserId(userId);

            Subscription subscription =
                    result.orElse(new Subscription());

            LocalDateTime now = LocalDateTime.now();

            subscription.setUserId(userId);
            subscription.setBillingKey(billingKey);
            subscription.setCustomerKey(customerKey);
            subscription.setAmount(amount);
            subscription.setStatus("ACTIVE");

            if (subscription.getStartedAt() == null) {
                subscription.setStartedAt(now);
            }

            subscription.setExpiredAt(null);
            subscription.setNextPaymentAt(null);

            return subscriptionRepository.save(subscription);

        } catch (HttpClientErrorException e) {
            return "BillingKey 諛쒓툒 ?ㅻ쪟 : " + e.getResponseBodyAsString();
        } catch (Exception e) {
            return "BillingKey 泥섎━ 以??ㅻ쪟媛 諛쒖깮?덉뒿?덈떎.";
        }
    }

    @PostMapping("/billing/pay")
    public Object paySubscription(@RequestParam Long userId) {

        try {
            Optional<Subscription> result =
                    subscriptionRepository.findByUserId(userId);

            if (result.isEmpty()) {
                return "援щ룆 ?뺣낫媛 ?놁뒿?덈떎.";
            }

            Subscription subscription = result.get();

            if (!"ACTIVE".equals(subscription.getStatus())) {
                return "?꾩옱 ?쒖꽦?붾맂 援щ룆???꾨떃?덈떎.";
            }

            if (subscription.getBillingKey() == null
                    || subscription.getBillingKey().isBlank()) {
                return "billingKey媛 ?놁뒿?덈떎.";
            }

            if (subscription.getCustomerKey() == null
                    || subscription.getCustomerKey().isBlank()) {
                return "customerKey媛 ?놁뒿?덈떎.";
            }

            if (subscription.getAmount() == null
                    || subscription.getAmount() <= 0) {
                return "援щ룆 湲덉븸???щ컮瑜댁? ?딆뒿?덈떎.";
            }

            HttpHeaders headers = makeHeaders(billingSecretKey);

            String orderId =
                    "SAFEHOUSE-SUB-" + userId + "-" + System.currentTimeMillis();

            Map<String, Object> body = new HashMap<>();
            body.put("customerKey", subscription.getCustomerKey());
            body.put("amount", subscription.getAmount());
            body.put("orderId", orderId);
            body.put("orderName", "SafeHouse ??援щ룆");

            ResponseEntity<String> response = new RestTemplate().exchange(
                    "https://api.tosspayments.com/v1/billing/"
                            + subscription.getBillingKey(),
                    HttpMethod.POST,
                    new HttpEntity<>(body, headers),
                    String.class
            );

            if (!response.getStatusCode().is2xxSuccessful()) {
                return "??援щ룆 寃곗젣???ㅽ뙣?덉뒿?덈떎.";
            }

            JsonNode json = new ObjectMapper().readTree(response.getBody());
            String paymentKey = json.path("paymentKey").asText();

            Payment payment = new Payment();
            payment.setUserId(userId);
            payment.setPaymentKey(paymentKey);
            payment.setOrderId(orderId);
            payment.setAmount(subscription.getAmount());
            payment.setPaymentType("SUBSCRIPTION");
            payment.setStatus("PAID");

            Payment savedPayment = paymentRepository.save(payment);

            LocalDateTime now = LocalDateTime.now();

            if (subscription.getStartedAt() == null) {
                subscription.setStartedAt(now);
            }

            subscription.setExpiredAt(now.plusMonths(1));
            subscription.setNextPaymentAt(now.plusMonths(1));
            subscription.setStatus("ACTIVE");

            subscriptionRepository.save(subscription);

            return savedPayment;

        } catch (HttpClientErrorException e) {
            return "??援щ룆 寃곗젣 ?ㅻ쪟 : " + e.getResponseBodyAsString();
        } catch (Exception e) {
            return "??援щ룆 泥섎━ 以??ㅻ쪟媛 諛쒖깮?덉뒿?덈떎.";
        }
    }

    @PostMapping("/billing/cancel")
    public Object cancelSubscription(@RequestParam Long userId) {

        Optional<Subscription> result =
                subscriptionRepository.findByUserId(userId);

        if (result.isEmpty()) {
            return "援щ룆 ?뺣낫媛 ?놁뒿?덈떎.";
        }

        Subscription subscription = result.get();

        if ("CANCELED".equals(subscription.getStatus())) {
            return "?대? ?댁???援щ룆?낅땲??";
        }

        subscription.setStatus("CANCELED");
        subscription.setNextPaymentAt(null);

        subscriptionRepository.save(subscription);

        return "援щ룆???댁??섏뿀?듬땲??";
    }

    private HttpHeaders makeHeaders(String key) {

        String authorization = Base64.getEncoder().encodeToString(
                (key + ":").getBytes(StandardCharsets.UTF_8)
        );

        HttpHeaders headers = new HttpHeaders();
        headers.set("Authorization", "Basic " + authorization);
        headers.setContentType(MediaType.APPLICATION_JSON);

        return headers;
    }
}
