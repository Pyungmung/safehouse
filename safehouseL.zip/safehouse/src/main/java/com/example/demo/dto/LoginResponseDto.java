package com.example.demo.dto;

public class LoginResponseDto {

    // Access Token
    // 湲곗〈 ?꾨줎?몄? ?명솚?섍린 ?꾪빐 ?대쫫? token 洹몃?濡??ъ슜
    private String token;

    // Refresh Token
    private String refreshToken;

    private Long id;
    private String username;
    private String email;

    public LoginResponseDto(
            String token,
            String refreshToken,
            Long id,
            String username,
            String email) {

        this.token = token;
        this.refreshToken = refreshToken;
        this.id = id;
        this.username = username;
        this.email = email;
    }

    public String getToken() {
        return token;
    }

    public String getRefreshToken() {
        return refreshToken;
    }

    public Long getId() {
        return id;
    }

    public String getUsername() {
        return username;
    }

    public String getEmail() {
        return email;
    }
}
