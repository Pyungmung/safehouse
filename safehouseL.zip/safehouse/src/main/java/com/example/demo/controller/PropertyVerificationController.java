package com.example.demo.controller;

import java.time.LocalDateTime;
import java.util.Optional;
import java.util.UUID;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.entity.Payment;
import com.example.demo.entity.PropertyVerification;
import com.example.demo.repository.PaymentRepository;
import com.example.demo.repository.PropertyVerificationRepository;

@RestController
@RequestMapping("/api/verification")
public class PropertyVerificationController {

    private final PropertyVerificationRepository verificationRepository;
    private final PaymentRepository paymentRepository;

    public PropertyVerificationController(
            PropertyVerificationRepository verificationRepository,
            PaymentRepository paymentRepository) {

        this.verificationRepository = verificationRepository;
        this.paymentRepository = paymentRepository;
    }

    @PostMapping("/issue")
    public PropertyVerification issueVerification(
            @RequestParam Long propertyId,
            @RequestParam Long userId) {

        Optional<Payment> paymentResult =
                paymentRepository
                        .findFirstByUserIdAndPaymentTypeAndStatus(
                                userId,
                                "REPORT",
                                "PAID"
                        );

        if (paymentResult.isEmpty()) {
            System.out.println("?몄쬆留덊겕 諛쒓툒 ?ㅽ뙣 : REPORT 寃곗젣 ?댁뿭 ?놁쓬");
            return null;
        }

        Optional<PropertyVerification> existing =
                verificationRepository.findByPropertyId(propertyId);

        if (existing.isPresent()) {
            return existing.get();
        }

        PropertyVerification verification =
                new PropertyVerification();

        verification.setPropertyId(propertyId);
        verification.setVerified(true);

        String verificationCode =
                "SH-"
                + UUID.randomUUID()
                        .toString()
                        .substring(0, 8)
                        .toUpperCase();

        verification.setVerificationCode(verificationCode);
        verification.setVerifiedAt(LocalDateTime.now());

        return verificationRepository.save(verification);
    }

    @GetMapping
    public PropertyVerification getVerification(
            @RequestParam Long propertyId) {

        Optional<PropertyVerification> result =
                verificationRepository.findByPropertyId(propertyId);

        return result.orElse(null);
    }
}
