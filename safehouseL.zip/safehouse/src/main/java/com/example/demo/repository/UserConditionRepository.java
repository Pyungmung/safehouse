package com.example.demo.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.demo.entity.UserCondition;

public interface UserConditionRepository
        extends JpaRepository<UserCondition, Long> {

    Optional<UserCondition> findByUserId(Long userId);
}
