package com.example.demo.entity;

import java.time.LocalDateTime;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "subscription")
public class Subscription {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    // ?ъ슜??踰덊샇
    private Long userId;

    // Toss?먯꽌 諛쒓툒諛쏆? billingKey
    private String billingKey;

    // billingKey? ?곌껐?섎뒗 怨좉컼 ??
    private String customerKey;

    // ??援щ룆 湲덉븸
    private Long amount;

    // ACTIVE = 援щ룆以?
    // CANCELED = 援щ룆?댁?
    private String status;

    // 援щ룆 ?쒖옉??
    private LocalDateTime startedAt;

    // 援щ룆 留뚮즺??
    private LocalDateTime expiredAt;

    // ?ㅼ쓬 寃곗젣 ?덉젙??
    private LocalDateTime nextPaymentAt;

    public Subscription() {}

    public Long getId() {
        return id;
    }

    public Long getUserId() {
        return userId;
    }

    public void setUserId(Long userId) {
        this.userId = userId;
    }

    public String getBillingKey() {
        return billingKey;
    }

    public void setBillingKey(String billingKey) {
        this.billingKey = billingKey;
    }

    public String getCustomerKey() {
        return customerKey;
    }

    public void setCustomerKey(String customerKey) {
        this.customerKey = customerKey;
    }

    public Long getAmount() {
        return amount;
    }

    public void setAmount(Long amount) {
        this.amount = amount;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public LocalDateTime getStartedAt() {
        return startedAt;
    }

    public void setStartedAt(LocalDateTime startedAt) {
        this.startedAt = startedAt;
    }

    public LocalDateTime getExpiredAt() {
        return expiredAt;
    }

    public void setExpiredAt(LocalDateTime expiredAt) {
        this.expiredAt = expiredAt;
    }

    public LocalDateTime getNextPaymentAt() {
        return nextPaymentAt;
    }

    public void setNextPaymentAt(LocalDateTime nextPaymentAt) {
        this.nextPaymentAt = nextPaymentAt;
    }
}
