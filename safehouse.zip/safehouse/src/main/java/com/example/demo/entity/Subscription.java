package com.example.demo.entity;

import java.time.LocalDateTime;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "subscription")
public class Subscription {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    // 사용자 번호
    private Long userId;

    // Toss에서 발급받은 billingKey
    private String billingKey;

    // billingKey와 연결되는 고객 키
    private String customerKey;

    // 월 구독 금액
    private Long amount;

    // ACTIVE = 구독중
    // CANCELED = 구독해지
    private String status;

    // 구독 시작일
    private LocalDateTime startedAt;

    // 구독 만료일
    private LocalDateTime expiredAt;

    // 다음 결제 예정일
    private LocalDateTime nextPaymentAt;

    public Subscription() {}

    public Long getId() {
        return id;
    }

    public Long getUserId() {
        return userId;
    }

    public void setUserId(Long userId) {
        this.userId = userId;
    }

    public String getBillingKey() {
        return billingKey;
    }

    public void setBillingKey(String billingKey) {
        this.billingKey = billingKey;
    }

    public String getCustomerKey() {
        return customerKey;
    }

    public void setCustomerKey(String customerKey) {
        this.customerKey = customerKey;
    }

    public Long getAmount() {
        return amount;
    }

    public void setAmount(Long amount) {
        this.amount = amount;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public LocalDateTime getStartedAt() {
        return startedAt;
    }

    public void setStartedAt(LocalDateTime startedAt) {
        this.startedAt = startedAt;
    }

    public LocalDateTime getExpiredAt() {
        return expiredAt;
    }

    public void setExpiredAt(LocalDateTime expiredAt) {
        this.expiredAt = expiredAt;
    }

    public LocalDateTime getNextPaymentAt() {
        return nextPaymentAt;
    }

    public void setNextPaymentAt(LocalDateTime nextPaymentAt) {
        this.nextPaymentAt = nextPaymentAt;
    }
}