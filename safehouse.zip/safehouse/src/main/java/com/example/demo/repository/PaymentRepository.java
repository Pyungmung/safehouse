package com.example.demo.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.demo.entity.Payment;

public interface PaymentRepository
        extends JpaRepository<Payment, Long> {

    // 주문번호로 결제 찾기
    Optional<Payment> findByOrderId(String orderId);

    // Toss paymentKey로 결제 찾기
    Optional<Payment> findByPaymentKey(String paymentKey);

    // 사용자 + 결제종류 + 결제상태로 결제 찾기
    Optional<Payment> findFirstByUserIdAndPaymentTypeAndStatus(
            Long userId,
            String paymentType,
            String status
    );
}