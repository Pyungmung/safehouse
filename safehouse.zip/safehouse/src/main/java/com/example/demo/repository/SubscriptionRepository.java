package com.example.demo.repository;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.demo.entity.Subscription;

public interface SubscriptionRepository
        extends JpaRepository<Subscription, Long> {

    // 사용자 번호로 구독 조회
    Optional<Subscription> findByUserId(Long userId);

    // ACTIVE 상태인 구독 전체 조회
    List<Subscription> findByStatus(String status);

    // ACTIVE 상태이면서 결제일이 된 구독 조회
    List<Subscription> findByStatusAndNextPaymentAtLessThanEqual(
            String status,
            LocalDateTime now
    );
}