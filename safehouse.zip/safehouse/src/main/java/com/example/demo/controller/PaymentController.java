package com.example.demo.controller;

import java.nio.charset.StandardCharsets;
import java.time.LocalDateTime;
import java.util.Base64;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestTemplate;

import com.example.demo.entity.Payment;
import com.example.demo.entity.Subscription;
import com.example.demo.repository.PaymentRepository;
import com.example.demo.repository.SubscriptionRepository;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

@RestController
@RequestMapping("/api/payment")
public class PaymentController {

    private final PaymentRepository paymentRepository;
    private final SubscriptionRepository subscriptionRepository;

    @Value("${tosspayments.secret-key}")
    private String secretKey;

    @Value("${tosspayments.billing-secret-key}")
    private String billingSecretKey;

    public PaymentController(
            PaymentRepository paymentRepository,
            SubscriptionRepository subscriptionRepository) {
        this.paymentRepository = paymentRepository;
        this.subscriptionRepository = subscriptionRepository;
    }

    @PostMapping("/report/confirm")
    public Object confirmReportPayment(
            @RequestParam Long userId,
            @RequestParam String paymentKey,
            @RequestParam String orderId,
            @RequestParam Long amount) {

        try {
            if (amount == null || amount <= 0) {
                return "결제 금액이 올바르지 않습니다.";
            }

            HttpHeaders headers = makeHeaders(secretKey);

            Map<String, Object> body = new HashMap<>();
            body.put("paymentKey", paymentKey);
            body.put("orderId", orderId);
            body.put("amount", amount);

            ResponseEntity<String> response = new RestTemplate().exchange(
                    "https://api.tosspayments.com/v1/payments/confirm",
                    HttpMethod.POST,
                    new HttpEntity<>(body, headers),
                    String.class
            );

            if (!response.getStatusCode().is2xxSuccessful()) {
                return "결제 승인에 실패했습니다.";
            }

            Payment payment = new Payment();
            payment.setUserId(userId);
            payment.setPaymentKey(paymentKey);
            payment.setOrderId(orderId);
            payment.setAmount(amount);
            payment.setPaymentType("REPORT");
            payment.setStatus("PAID");

            return paymentRepository.save(payment);

        } catch (HttpClientErrorException e) {
            return "Toss 결제 오류 : " + e.getResponseBodyAsString();
        } catch (Exception e) {
            return "결제 처리 중 오류가 발생했습니다.";
        }
    }

    @PostMapping("/billing/issue")
    public Object issueBillingKey(
            @RequestParam Long userId,
            @RequestParam String authKey,
            @RequestParam String customerKey,
            @RequestParam Long amount) {

        try {
            if (amount == null || amount <= 0) {
                return "구독 금액이 올바르지 않습니다.";
            }

            HttpHeaders headers = makeHeaders(billingSecretKey);

            Map<String, Object> body = new HashMap<>();
            body.put("authKey", authKey);
            body.put("customerKey", customerKey);

            ResponseEntity<String> response = new RestTemplate().exchange(
                    "https://api.tosspayments.com/v1/billing/authorizations/issue",
                    HttpMethod.POST,
                    new HttpEntity<>(body, headers),
                    String.class
            );

            if (!response.getStatusCode().is2xxSuccessful()) {
                return "BillingKey 발급에 실패했습니다.";
            }

            JsonNode json = new ObjectMapper().readTree(response.getBody());
            String billingKey = json.path("billingKey").asText();

            Optional<Subscription> result =
                    subscriptionRepository.findByUserId(userId);

            Subscription subscription =
                    result.orElse(new Subscription());

            LocalDateTime now = LocalDateTime.now();

            subscription.setUserId(userId);
            subscription.setBillingKey(billingKey);
            subscription.setCustomerKey(customerKey);
            subscription.setAmount(amount);
            subscription.setStatus("ACTIVE");

            if (subscription.getStartedAt() == null) {
                subscription.setStartedAt(now);
            }

            subscription.setExpiredAt(null);
            subscription.setNextPaymentAt(null);

            return subscriptionRepository.save(subscription);

        } catch (HttpClientErrorException e) {
            return "BillingKey 발급 오류 : " + e.getResponseBodyAsString();
        } catch (Exception e) {
            return "BillingKey 처리 중 오류가 발생했습니다.";
        }
    }

    @PostMapping("/billing/pay")
    public Object paySubscription(@RequestParam Long userId) {

        try {
            Optional<Subscription> result =
                    subscriptionRepository.findByUserId(userId);

            if (result.isEmpty()) {
                return "구독 정보가 없습니다.";
            }

            Subscription subscription = result.get();

            if (!"ACTIVE".equals(subscription.getStatus())) {
                return "현재 활성화된 구독이 아닙니다.";
            }

            if (subscription.getBillingKey() == null
                    || subscription.getBillingKey().isBlank()) {
                return "billingKey가 없습니다.";
            }

            if (subscription.getCustomerKey() == null
                    || subscription.getCustomerKey().isBlank()) {
                return "customerKey가 없습니다.";
            }

            if (subscription.getAmount() == null
                    || subscription.getAmount() <= 0) {
                return "구독 금액이 올바르지 않습니다.";
            }

            HttpHeaders headers = makeHeaders(billingSecretKey);

            String orderId =
                    "SAFEHOUSE-SUB-" + userId + "-" + System.currentTimeMillis();

            Map<String, Object> body = new HashMap<>();
            body.put("customerKey", subscription.getCustomerKey());
            body.put("amount", subscription.getAmount());
            body.put("orderId", orderId);
            body.put("orderName", "SafeHouse 월 구독");

            ResponseEntity<String> response = new RestTemplate().exchange(
                    "https://api.tosspayments.com/v1/billing/"
                            + subscription.getBillingKey(),
                    HttpMethod.POST,
                    new HttpEntity<>(body, headers),
                    String.class
            );

            if (!response.getStatusCode().is2xxSuccessful()) {
                return "월 구독 결제에 실패했습니다.";
            }

            JsonNode json = new ObjectMapper().readTree(response.getBody());
            String paymentKey = json.path("paymentKey").asText();

            Payment payment = new Payment();
            payment.setUserId(userId);
            payment.setPaymentKey(paymentKey);
            payment.setOrderId(orderId);
            payment.setAmount(subscription.getAmount());
            payment.setPaymentType("SUBSCRIPTION");
            payment.setStatus("PAID");

            Payment savedPayment = paymentRepository.save(payment);

            LocalDateTime now = LocalDateTime.now();

            if (subscription.getStartedAt() == null) {
                subscription.setStartedAt(now);
            }

            subscription.setExpiredAt(now.plusMonths(1));
            subscription.setNextPaymentAt(now.plusMonths(1));
            subscription.setStatus("ACTIVE");

            subscriptionRepository.save(subscription);

            return savedPayment;

        } catch (HttpClientErrorException e) {
            return "월 구독 결제 오류 : " + e.getResponseBodyAsString();
        } catch (Exception e) {
            return "월 구독 처리 중 오류가 발생했습니다.";
        }
    }

    @PostMapping("/billing/cancel")
    public Object cancelSubscription(@RequestParam Long userId) {

        Optional<Subscription> result =
                subscriptionRepository.findByUserId(userId);

        if (result.isEmpty()) {
            return "구독 정보가 없습니다.";
        }

        Subscription subscription = result.get();

        if ("CANCELED".equals(subscription.getStatus())) {
            return "이미 해지된 구독입니다.";
        }

        subscription.setStatus("CANCELED");
        subscription.setNextPaymentAt(null);

        subscriptionRepository.save(subscription);

        return "구독이 해지되었습니다.";
    }

    private HttpHeaders makeHeaders(String key) {

        String authorization = Base64.getEncoder().encodeToString(
                (key + ":").getBytes(StandardCharsets.UTF_8)
        );

        HttpHeaders headers = new HttpHeaders();
        headers.set("Authorization", "Basic " + authorization);
        headers.setContentType(MediaType.APPLICATION_JSON);

        return headers;
    }
}