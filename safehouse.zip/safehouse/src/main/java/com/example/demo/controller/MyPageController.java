package com.example.demo.controller;

import java.util.Optional;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.entity.UserCondition;
import com.example.demo.repository.UserConditionRepository;

@RestController
@RequestMapping("/api/mypage")
public class MyPageController {

    private final UserConditionRepository repository;

    public MyPageController(UserConditionRepository repository) {
        this.repository = repository;
    }

    @PostMapping("/condition")
    public UserCondition saveCondition(
            @RequestParam Long userId,
            @RequestBody UserCondition condition) {

        condition.setUserId(userId);
        return repository.save(condition);
    }

    @GetMapping("/condition")
    public UserCondition getCondition(@RequestParam Long userId) {

        Optional<UserCondition> result =
                repository.findByUserId(userId);

        return result.orElse(null);
    }

    @PutMapping("/condition")
    public UserCondition updateCondition(
            @RequestParam Long userId,
            @RequestBody UserCondition newCondition) {

        Optional<UserCondition> result =
                repository.findByUserId(userId);

        if (result.isEmpty()) {
            return null;
        }

        UserCondition condition = result.get();

        condition.setSalary(newCondition.getSalary());
        condition.setWorkplace(newCondition.getWorkplace());
        condition.setDeposit(newCondition.getDeposit());
        condition.setNotificationEnabled(
                newCondition.getNotificationEnabled()
        );

        return repository.save(condition);
    }
}